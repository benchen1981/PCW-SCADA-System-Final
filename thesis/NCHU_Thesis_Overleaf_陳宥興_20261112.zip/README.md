# 國立中興大學碩士論文 Overleaf 專案

## 上傳方式

1. 在 Overleaf 選擇 **New Project → Upload Project**。
2. 上傳本專案 ZIP，不需要先解壓。
3. 在 **Menu → Compiler** 選擇 **XeLaTeX**。
4. Main document 設為 `main.tex`。
5. 按 **Recompile**。

## 專案結構

- `main.tex`：論文主文件與學校制式封面。
- `kaiu.ttf`：標楷體字型，請勿刪除。
- `picture/`：論文全部圖片。
- `refs.bib`：保留供後續改用 BibLaTeX；目前正文參考文獻已內嵌於 `main.tex`，不需要執行 Biber。

## 封面資料

- 學程：國立中興大學人工智慧與資料科學碩士在職學位學程
- 類別：碩士學位論文
- 中文題目：半導體製程冷卻水系統時間序列監測的異常檢測與預警
- 英文題目：Anomaly Detection and Early Warning for Time-Series Monitoring of Semiconductor Process Cooling Water Systems
- 指導教授：吳宏達
- 研究生：陳 宥興
- 日期：中華民國一百一十五年十一月

## 注意

第二頁目前為「口試審核頁預留」。取得正式簽核掃描 PDF 後，依 `main.tex` 中的註解替換即可。
